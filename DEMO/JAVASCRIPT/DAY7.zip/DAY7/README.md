function  Expression :- 

let a = 10;

let demo = function(){
    clg("");
}


// nested function 

function parent(){

    function child(){

    }
    child()
}
parent()


// 1. multiply of 3 numbers using the function expression.
// 2. divide of 2 numbers using the function declaration.
// 3. sum or subtract of 2 numbers using the function expression.



// 1. sum of three number using the Arrow function.
// 2  Write	a program to find the FACTORIAL	of	a given	number where number 6?
// 3. prime number using the arrow function.  -> 2 , 3 , 5 , 7 , 11 , 13 , 17
// 4. perfect number using the arrow function. -> 6 , 28